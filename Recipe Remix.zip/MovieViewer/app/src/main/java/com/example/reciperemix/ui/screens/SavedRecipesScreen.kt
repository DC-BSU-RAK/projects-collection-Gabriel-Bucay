package com.example.reciperemix.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.graphics.painter.ColorPainter
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.RemixText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedRecipesScreen(
    recipeManager: RecipeManager,
    onNavigateToHome: () -> Unit,
    onNavigateToPreferences: () -> Unit,
    onBack: () -> Unit
) {
    var savedRecipes by remember { 
        mutableStateOf(recipeManager.getSavedRecipes())
    }
    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    val filteredRecipes = if (searchQuery.isEmpty()) {
        savedRecipes
    } else {
        savedRecipes.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearching) {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search recipes...") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Saved Recipes 🌿", style = MaterialTheme.typography.titleMedium, color = RemixText)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (isSearching) { { isSearching = false; searchQuery = "" } } else onBack) {
                        Icon(if (isSearching) Icons.Default.Close else Icons.Default.ArrowBack, contentDescription = if (isSearching) "Clear Search" else "Back", tint = RemixText)
                    }
                },
                actions = {
                    if (!isSearching) {
                        IconButton(onClick = { isSearching = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = RemixText)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = false,
                    onClick = onNavigateToHome
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Saved Recipes") },
                    label = { Text("Saved") },
                    selected = true,
                    onClick = { }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Preferences") },
                    label = { Text("Preferences") },
                    selected = false,
                    onClick = onNavigateToPreferences
                )
            }
        },
        containerColor = Color(0xFFFBF5F0)
    ) { padding ->
        if (savedRecipes.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("No saved recipes yet!", color = RemixText.copy(alpha = 0.5f))
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
            ) {
                items(savedRecipes) { recipe ->
                    SavedRecipeCard(
                        name = recipe,
                        onDelete = {
                            recipeManager.deleteRecipe(recipe)
                            savedRecipes = recipeManager.getSavedRecipes()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SavedRecipeCard(name: String, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RemixSecondary),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=150&auto=format&fit=crop",
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(RemixSecondary),
                    error = ColorPainter(RemixSecondary)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleSmall,
                    color = RemixText,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Today",
                    style = MaterialTheme.typography.labelSmall,
                    color = RemixText.copy(alpha = 0.4f)
                )
            }
            
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Favorite, contentDescription = "Unsave", tint = RemixPrimary)
            }
        }
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun SavedRecipesScreenPreview() {
    val context = androidx.compose.ui.platform.LocalContext.current
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            SavedRecipesScreen(
                recipeManager = RecipeManager(context),
                onNavigateToHome = {},
                onNavigateToPreferences = {},
                onBack = {}
            )
        }
    }
}
