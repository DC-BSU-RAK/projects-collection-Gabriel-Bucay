package com.example.reciperemix.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Colors
val CreamBackground = Color(0xFFFBF5F0)
val SoftTan = Color(0xFFF3E5D8)
val DeepBrown = Color(0xFF3E2723)
val MutedGreen = Color(0xFF6B7D6A)
val WarmOrange = Color(0xFFD8704D)
val LightCoral = Color(0xFFE89E8A)

val RemixPrimary = WarmOrange
val RemixSecondary = SoftTan
val RemixAccent = MutedGreen
val RemixText = DeepBrown
val RemixBackground = CreamBackground

// Typography
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
)

private val DarkColorScheme = darkColorScheme(
    primary = RemixPrimary,
    onPrimary = Color.White,
    secondary = RemixSecondary,
    onSecondary = RemixText,
    tertiary = RemixAccent,
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E),
    onSurface = Color.White,
    onBackground = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = RemixPrimary,
    onPrimary = Color.White,
    secondary = RemixSecondary,
    onSecondary = RemixText,
    tertiary = RemixAccent,
    background = RemixBackground,
    surface = Color.White,
    onPrimaryContainer = RemixText,
    onSurface = RemixText,
    onBackground = RemixText
)

@Composable
fun RecipeRemixTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
