package com.example.reciperemix

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.screens.AboutScreen
import com.example.reciperemix.ui.screens.HomeScreen
import com.example.reciperemix.ui.screens.IngredientSelectorScreen
import com.example.reciperemix.ui.screens.PreferencesScreen
import com.example.reciperemix.ui.screens.RecipeGenerationScreen
import com.example.reciperemix.ui.screens.SavedRecipesScreen
import com.example.reciperemix.ui.theme.RecipeRemixTheme

import com.example.reciperemix.ui.screens.SplashScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val recipeManager = remember { RecipeManager(context) }
            var isDarkMode by remember { mutableStateOf(recipeManager.getBooleanPreference("dark_theme", false)) }

            RecipeRemixTheme(darkTheme = isDarkMode) {
                RecipeRemixApp(
                    recipeManager = recipeManager,
                    onThemeChange = { isDarkMode = it }
                )
            }
        }
    }
}

@Composable
fun RecipeRemixApp(recipeManager: RecipeManager, onThemeChange: (Boolean) -> Unit) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(onTimeout = {
                navController.navigate("home") {
                    popUpTo("splash") { inclusive = true }
                }
            })
        }
        composable("home") {
            HomeScreen(
                onStartRemix = { navController.navigate("ingredient_selector") },
                onViewSaved = { navController.navigate("saved_recipes") },
                onViewPreferences = { navController.navigate("preferences") },
                onViewAbout = { navController.navigate("about") }
            )
        }
        composable("ingredient_selector") {
            IngredientSelectorScreen(
                recipeManager = recipeManager,
                onGenerateRecipe = { ingredients, theme ->
                    navController.navigate("recipe_generation/$ingredients/$theme")
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable("recipe_generation/{ingredients}/{theme}") { backStackEntry ->
            val ingredients = backStackEntry.arguments?.getString("ingredients") ?: ""
            val theme = backStackEntry.arguments?.getString("theme") ?: ""
            RecipeGenerationScreen(
                ingredients = ingredients,
                theme = theme,
                onSaveRecipe = { recipeName -> 
                    recipeManager.saveRecipe(recipeName)
                },
                onViewPlating = { navController.navigate("plating_ideas") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("plating_ideas") {
            // PlatingIdeasScreen will be implemented next
            com.example.reciperemix.ui.screens.PlatingIdeasScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable("saved_recipes") {
            SavedRecipesScreen(
                recipeManager = recipeManager,
                onNavigateToHome = { navController.navigate("home") { popUpTo("home") { inclusive = true } } },
                onNavigateToPreferences = { navController.navigate("preferences") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("preferences") {
            PreferencesScreen(
                recipeManager = recipeManager,
                onThemeChange = onThemeChange,
                onBack = { navController.popBackStack() }
            )
        }
        composable("about") {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
