package com.example.reciperemix

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.screens.HomeScreen
import com.example.reciperemix.ui.theme.RecipeRemixTheme

class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val recipeManager = remember { RecipeManager(context) }
            var isDarkMode by remember { mutableStateOf(recipeManager.getBooleanPreference("dark_theme", false)) }

            RecipeRemixTheme(darkTheme = isDarkMode) {
                HomeScreen(
                    onStartRemix = { 
                        val intent = Intent(this@HomeActivity, RecipeFlowActivity::class.java).apply {
                            putExtra("start_destination", "ingredient_selector")
                        }
                        startActivity(intent)
                    },
                    onViewSaved = {
                        val intent = Intent(this@HomeActivity, RecipeFlowActivity::class.java).apply {
                            putExtra("start_destination", "saved_recipes")
                        }
                        startActivity(intent)
                    },
                    onViewPreferences = {
                        val intent = Intent(this@HomeActivity, RecipeFlowActivity::class.java).apply {
                            putExtra("start_destination", "preferences")
                        }
                        startActivity(intent)
                    },
                    onViewAbout = {
                        val intent = Intent(this@HomeActivity, RecipeFlowActivity::class.java).apply {
                            putExtra("start_destination", "about")
                        }
                        startActivity(intent)
                    }
                )
            }
        }
        
        // Show instructions popup on first launch
        val recipeManager = RecipeManager(this)
        if (recipeManager.getBooleanPreference("first_launch", true)) {
            startActivity(Intent(this, InstructionsActivity::class.java))
            recipeManager.saveBooleanPreference("first_launch", false)
        }
    }
}
