package com.example.reciperemix.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixText
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "splash")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    val alpha by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(1000),
        label = "alpha"
    )

    LaunchedEffect(Unit) {
        delay(2500) // 2.5 seconds splash
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFBF5F0), Color(0xFFF3E5D8))
                )
            )
            .semantics { contentDescription = "Recipe Remix Splash Screen" },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                // Animated circles
                Canvas(modifier = Modifier.fillMaxSize().scale(scale)) {
                    drawCircle(
                        color = RemixPrimary.copy(alpha = 0.2f),
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
                Text(
                    text = "🍳",
                    fontSize = 80.sp,
                    modifier = Modifier.scale(scale)
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "RECIPE",
                style = MaterialTheme.typography.displaySmall,
                color = RemixText,
                fontFamily = FontFamily.Serif,
                letterSpacing = 8.sp,
                modifier = Modifier.alpha(alpha)
            )
            Text(
                text = "Remix",
                style = MaterialTheme.typography.displayMedium,
                color = RemixPrimary,
                fontFamily = FontFamily.Cursive,
                modifier = Modifier.offset(y = (-12).dp).alpha(alpha)
            )
        }
    }
}
