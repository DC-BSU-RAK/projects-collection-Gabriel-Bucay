package com.example.reciperemix.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.graphics.painter.ColorPainter
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.RemixText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlatingIdeasScreen(onBack: () -> Unit) {
    var currentImageIndex by remember { mutableStateOf(0) }
    val images = listOf(
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1473093226795-af9932fe5856?q=80&w=600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?q=80&w=600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1493770348161-369560ae357d?q=80&w=600&auto=format&fit=crop"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("Plating Ideas ✨", style = MaterialTheme.typography.titleMedium, color = RemixText)
                        Text("Make it look as good as it tastes", style = MaterialTheme.typography.bodySmall, color = RemixText.copy(alpha = 0.6f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = RemixText)
                    }
                },
                actions = { Spacer(modifier = Modifier.width(48.dp)) }, // To center title
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color(0xFFFBF5F0)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Carousel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(RemixSecondary.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = images[currentImageIndex],
                    contentDescription = "Plating Idea",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(RemixSecondary),
                    error = ColorPainter(RemixSecondary)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { 
                            currentImageIndex = if (currentImageIndex > 0) currentImageIndex - 1 else images.size - 1 
                        }, 
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color.White.copy(alpha = 0.7f))
                    ) { 
                        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous") 
                    }
                    
                    IconButton(
                        onClick = { 
                            currentImageIndex = (currentImageIndex + 1) % images.size 
                        }, 
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color.White.copy(alpha = 0.7f))
                    ) { 
                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next") 
                    }
                }
                
                // Indicators
                Row(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    images.forEachIndexed { index, _ ->
                        Box(
                            modifier = Modifier
                                .size(if (index == currentImageIndex) 12.dp else 8.dp, 8.dp)
                                .clip(CircleShape)
                                .background(if (index == currentImageIndex) RemixPrimary else Color.White)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Tips Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = RemixSecondary.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        "Tips & Inspiration",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = RemixText
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    val tips = listOf(
                        "Use a wide plate with a neutral tone",
                        "Add fresh berries and edible flowers",
                        "Dust with powdered sugar",
                        "Drizzle sauce in a circular motion",
                        "Serve with warm lighting for extra cozy vibes"
                    )
                    
                    tips.forEach { tip ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text("✦", color = RemixPrimary, modifier = Modifier.padding(end = 8.dp))
                            Text(tip, style = MaterialTheme.typography.bodySmall, color = RemixText.copy(alpha = 0.8f))
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Color Palette
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Color Palette",
                    style = MaterialTheme.typography.labelLarge,
                    color = RemixText.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(Color(0xFFFBF5F0), Color(0xFFF2E7D5), Color(0xFFD8704D), Color(0xFF3E2723), Color(0xFF6B7D6A)).forEach { color ->
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(1.dp, Color.Gray.copy(alpha = 0.2f), CircleShape)
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun PlatingIdeasScreenPreview() {
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            PlatingIdeasScreen(onBack = {})
        }
    }
}
