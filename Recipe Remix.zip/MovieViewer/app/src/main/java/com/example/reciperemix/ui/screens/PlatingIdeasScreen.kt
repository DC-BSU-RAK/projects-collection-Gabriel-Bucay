package com.example.reciperemix.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.graphics.painter.ColorPainter
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.RemixText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlatingIdeasScreen(
    ingredients: String = "Strawberry",
    onBack: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    var currentImageIndex by remember { mutableStateOf(0) }
    val firstIngredient = remember(ingredients) { ingredients.split(",").firstOrNull()?.trim()?.lowercase() ?: "food" }
    
    val images = remember(firstIngredient) {
        listOf(
            "https://loremflickr.com/600/400/$firstIngredient,plating/all?lock=1",
            "https://loremflickr.com/600/400/$firstIngredient,dish/all?lock=2",
            "https://loremflickr.com/600/400/$firstIngredient,gourmet/all?lock=3",
            "https://loremflickr.com/600/400/plating,luxury/all?lock=4",
            "https://loremflickr.com/600/400/dessert,elegant/all?lock=5"
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("Plating Ideas ✨", style = MaterialTheme.typography.titleMedium, color = colorScheme.onSurface)
                        Text("Make it look as good as it tastes", style = MaterialTheme.typography.bodySmall, color = colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = colorScheme.onSurface)
                    }
                },
                actions = { Spacer(modifier = Modifier.width(48.dp)) }, // To center title
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Carousel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = images[currentImageIndex],
                    contentDescription = "Plating Idea",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(colorScheme.secondaryContainer),
                    error = ColorPainter(colorScheme.secondaryContainer)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { 
                            currentImageIndex = if (currentImageIndex > 0) currentImageIndex - 1 else images.size - 1 
                        }, 
                        colors = IconButtonDefaults.iconButtonColors(containerColor = colorScheme.surface.copy(alpha = 0.7f))
                    ) { 
                        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous", tint = colorScheme.onSurface) 
                    }
                    
                    IconButton(
                        onClick = { 
                            currentImageIndex = (currentImageIndex + 1) % images.size 
                        }, 
                        colors = IconButtonDefaults.iconButtonColors(containerColor = colorScheme.surface.copy(alpha = 0.7f))
                    ) { 
                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next", tint = colorScheme.onSurface) 
                    }
                }
                
                // Indicators
                Row(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    images.forEachIndexed { index, _ ->
                        Box(
                            modifier = Modifier
                                .size(if (index == currentImageIndex) 12.dp else 8.dp, 8.dp)
                                .clip(CircleShape)
                                .background(if (index == currentImageIndex) colorScheme.primary else colorScheme.surface)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Tips Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = colorScheme.secondaryContainer.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        "Tips & Inspiration",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = colorScheme.onSecondaryContainer
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    val tips = listOf(
                        "Use a wide plate with a neutral tone",
                        "Add fresh berries and edible flowers",
                        "Dust with powdered sugar",
                        "Drizzle sauce in a circular motion",
                        "Serve with warm lighting for extra cozy vibes"
                    )
                    
                    tips.forEach { tip ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text("✦", color = colorScheme.primary, modifier = Modifier.padding(end = 8.dp))
                            Text(tip, style = MaterialTheme.typography.bodySmall, color = colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Color Palette
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Color Palette",
                    style = MaterialTheme.typography.labelLarge,
                    color = colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(
                        colorScheme.primary,
                        colorScheme.secondary,
                        colorScheme.tertiary,
                        colorScheme.surfaceVariant,
                        colorScheme.outline
                    ).forEach { color ->
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(1.dp, colorScheme.outline.copy(alpha = 0.2f), CircleShape)
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun PlatingIdeasScreenPreview() {
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            PlatingIdeasScreen(onBack = {})
        }
    }
}
