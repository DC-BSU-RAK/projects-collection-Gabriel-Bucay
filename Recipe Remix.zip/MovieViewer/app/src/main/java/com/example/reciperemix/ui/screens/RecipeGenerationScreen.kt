package com.example.reciperemix.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.reciperemix.ui.theme.*
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.PathEffect

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeGenerationScreen(
    ingredients: String,
    theme: String,
    onSaveRecipe: (String) -> Unit,
    onViewPlating: () -> Unit,
    onBack: () -> Unit
) {
    val recipe = remember(ingredients, theme) { generateRecipe(ingredients, theme) }
    var isSaved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Your recipe is ready! ✨", style = MaterialTheme.typography.bodyMedium, color = RemixText.copy(alpha = 0.6f)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = RemixText)
                    }
                },
                actions = {
                    IconButton(onClick = { 
                        isSaved = !isSaved
                        if (isSaved) onSaveRecipe(recipe.name)
                    }) {
                        Icon(
                            if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Save",
                            tint = RemixPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color(0xFFFBF5F0)
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Decorative Background Elements
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = RemixPrimary.copy(alpha = 0.05f),
                    radius = 400.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(size.width, 0f)
                )
                drawCircle(
                    color = MutedGreen.copy(alpha = 0.05f),
                    radius = 300.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(0f, size.height * 0.7f)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = recipe.name,
                    style = MaterialTheme.typography.headlineMedium,
                    color = RemixPrimary,
                    fontFamily = FontFamily.Serif,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                SuggestionChip(
                    onClick = { },
                    label = { Text(theme, color = Color.White) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = MutedGreen),
                    border = null,
                    shape = CircleShape,
                    icon = { Text(getThemeEmoji(theme)) }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = recipe.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = RemixText.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Enhanced Image Container
                Box(
                    modifier = Modifier.size(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Rotating decorative rings
                    val infiniteTransition = rememberInfiniteTransition(label = "rings")
                    val rotation by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(10000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "rotation"
                    )

                    Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation }) {
                        drawCircle(
                            brush = Brush.sweepGradient(
                                colors = listOf(RemixPrimary, Color.Transparent, RemixPrimary.copy(alpha = 0.3f), RemixPrimary)
                            ),
                            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 20f)))
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(4.dp, Color.White, CircleShape)
                            .padding(4.dp)
                            .clip(CircleShape)
                            .background(RemixSecondary),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data("https://images.unsplash.com/photo-1567620905732-2d1ec7bb7445?q=80&w=400&auto=format&fit=crop")
                                .crossfade(true)
                                .build(),
                            contentDescription = "Generated Recipe Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            placeholder = ColorPainter(RemixSecondary),
                            error = ColorPainter(RemixSecondary)
                        )
                        Text(
                            getFoodEmoji(ingredients), 
                            fontSize = 60.sp, 
                            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                        )
                    }
                    
                    // Floating decorative emojis
                    Text("✨", fontSize = 24.sp, modifier = Modifier.align(Alignment.TopStart).offset(x = 20.dp, y = 20.dp))
                    Text("🌿", fontSize = 20.sp, modifier = Modifier.align(Alignment.BottomStart).offset(x = 10.dp, y = (-20).dp))
                    Text("🎨", fontSize = 22.sp, modifier = Modifier.align(Alignment.TopEnd).offset(x = (-10).dp, y = 10.dp))
                }
                
                Spacer(modifier = Modifier.height(40.dp))
            
                // Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = RemixSecondary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        InfoRow("Flavor Profile", recipe.flavor)
                        HorizontalDivider(color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
                        InfoRow("Mood", recipe.mood)
                        HorizontalDivider(color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))
                        InfoRow("Main Ingredients", recipe.mainIngredients)
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            isSaved = !isSaved
                            if (isSaved) onSaveRecipe(recipe.name)
                        },
                        modifier = Modifier.weight(1f).height(56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSaved) MutedGreen.copy(alpha = 0.8f) else MutedGreen
                        )
                    ) {
                        Icon(
                            if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isSaved) "Saved" else "Save Recipe")
                    }

                    IconButton(
                        onClick = { /* Share */ },
                        modifier = Modifier.size(56.dp).background(Color.White, RoundedCornerShape(12.dp))
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = RemixText)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onViewPlating,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RemixPrimary)
                ) {
                    Text("Plating Ideas ✨")
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Outlined.ArrowForward, contentDescription = null)
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun RecipeGenerationScreenPreview() {
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            RecipeGenerationScreen(
                ingredients = "Strawberry,Chocolate",
                theme = "Cozy Café",
                onSaveRecipe = { _ -> },
                onViewPlating = {},
                onBack = {}
            )
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = RemixText.copy(alpha = 0.6f),
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = RemixText,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1.5f)
        )
    }
}

data class RecipeResult(
    val name: String, 
    val description: String, 
    val plating: String,
    val flavor: String,
    val mood: String,
    val mainIngredients: String
)

fun getThemeEmoji(theme: String): String = when (theme) {
    "Cozy Café" -> "☕"
    "Fantasy" -> "🏰"
    "Cyberpunk" -> "🌆"
    "Gothic" -> "🧛"
    else -> "✨"
}

fun getFoodEmoji(ingredients: String): String {
    val first = ingredients.split(",").firstOrNull() ?: ""
    return when (first) {
        "Strawberry" -> "🍓"
        "Chocolate" -> "🍫"
        "Milk" -> "🥛"
        "Chicken" -> "🍗"
        "Bread" -> "🍞"
        else -> "🍛"
    }
}

fun generateRecipe(ingredients: String, theme: String): RecipeResult {
    val ingredientList = ingredients.split(",")
    val mainIngredient = ingredientList.firstOrNull() ?: "Mystery Item"
    
    val name = when (theme) {
        "Cozy Café" -> "$mainIngredient Cloud Pancakes"
        "Fantasy" -> "Enchanted $mainIngredient Stew"
        "Cyberpunk" -> "Neon $mainIngredient Fusion"
        "Gothic" -> "Midnight $mainIngredient Tower"
        else -> "$mainIngredient Remix"
    }
    
    val description = when (theme) {
        "Cozy Café" -> "Fluffy $mainIngredient goodness stacked high with cream and a touch of vanilla clouds."
        "Fantasy" -> "A magical concoction where $ingredients harmonize to create a dish fit for an elven feast."
        "Cyberpunk" -> "High-tech infusion of $ingredients, enhanced with synthetic flavors and a glowing aesthetic."
        "Gothic" -> "A dark and mysterious blend of $ingredients, offering a somber yet rich flavor profile."
        else -> "A creative mix of $ingredients that defies traditional culinary boundaries."
    }
    
    return RecipeResult(
        name = name,
        description = description,
        plating = "Served on a floating glass plate with edible glitter.",
        flavor = "Sweet • Creamy • Fruity",
        mood = "Warm • Cozy • Happy",
        mainIngredients = "Perfect Pairing\nVanilla Latte"
    )
}
