package com.example.reciperemix.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.RemixText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IngredientSelectorScreen(
    recipeManager: RecipeManager,
    onGenerateRecipe: (String, String) -> Unit,
    onBack: () -> Unit
) {
    val ingredientsList = listOf(
        "Strawberry" to "🍓", "Chocolate" to "🍫", "Milk" to "🥛",
        "Banana" to "🍌", "Bread" to "🍞", "Eggs" to "🥚",
        "Cheese" to "🧀", "Coffee" to "☕", "Chicken" to "🍗",
        "Basil" to "🌿", "Avocado" to "🥑", "Honey" to "🍯"
    )
    
    val themes = listOf(
        "Cozy Café" to "☕", "Fantasy" to "🏰", "Cyberpunk" to "🌆", "Gothic" to "🧛"
    )
    
    var selectedIngredients by remember { mutableStateOf(setOf<String>()) }
    var customIngredients by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var newIngredientName by remember { mutableStateOf("") }
    
    val allIngredients = ingredientsList + customIngredients
    
    val preferredTheme = remember { recipeManager.getPreference("favorite_theme", themes[0].first) }
    var selectedTheme by remember { mutableStateOf(preferredTheme) }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Ingredient") },
            text = {
                TextField(
                    value = newIngredientName,
                    onValueChange = { newIngredientName = it },
                    placeholder = { Text("e.g. Cinnamon") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newIngredientName.isNotBlank()) {
                            customIngredients = customIngredients + (newIngredientName to "✨")
                            newIngredientName = ""
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Add", color = RemixPrimary)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = RemixText)
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = RemixText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color(0xFFFBF5F0)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp)
        ) {
            Text(
                text = "Let's get creative! 🌿",
                style = MaterialTheme.typography.headlineSmall,
                color = RemixText,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Choose your ingredients and theme",
                style = MaterialTheme.typography.bodyMedium,
                color = RemixText.copy(alpha = 0.6f),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ingredients",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = RemixText
                )
                Text(
                    text = "${selectedIngredients.size} selected",
                    style = MaterialTheme.typography.bodySmall,
                    color = RemixText.copy(alpha = 0.5f)
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(allIngredients) { (name, emoji) ->
                    val isSelected = selectedIngredients.contains(name)
                    IngredientCard(
                        name = name,
                        emoji = emoji,
                        isSelected = isSelected,
                        onClick = {
                            selectedIngredients = if (isSelected) {
                                selectedIngredients - name
                            } else {
                                selectedIngredients + name
                            }
                        }
                    )
                }
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable(onClickLabel = "Add Custom Ingredient") { showAddDialog = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = "Add Icon", modifier = Modifier.size(16.dp), tint = Color.Gray)
                            Text("Add", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Choose a theme",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = RemixText,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(themes) { (theme, emoji) ->
                    ThemeCard(
                        name = theme,
                        emoji = emoji,
                        isSelected = selectedTheme == theme,
                        onClick = { selectedTheme = theme }
                    )
                }
            }

            Button(
                onClick = {
                    val ingredientsString = selectedIngredients.joinToString(",")
                    onGenerateRecipe(ingredientsString, selectedTheme)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RemixPrimary),
                enabled = selectedIngredients.isNotEmpty()
            ) {
                Text("Generate Recipe ✨", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun IngredientCard(name: String, emoji: String, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFF2E7D5) else Color.White
        ),
        border = if (isSelected) BorderStroke(1.dp, RemixPrimary.copy(alpha = 0.5f)) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = name,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
            )
            if (isSelected) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    tint = RemixPrimary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun ThemeCard(name: String, emoji: String, isSelected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(80.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (isSelected) RemixPrimary.copy(alpha = 0.1f) else Color.White)
                .border(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) RemixPrimary else Color.LightGray.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(emoji, fontSize = 32.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) RemixPrimary else RemixText,
            textAlign = TextAlign.Center
        )
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun IngredientSelectorScreenPreview() {
    val context = androidx.compose.ui.platform.LocalContext.current
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            IngredientSelectorScreen(
                recipeManager = RecipeManager(context),
                onGenerateRecipe = { _, _ -> },
                onBack = {}
            )
        }
    }
}
