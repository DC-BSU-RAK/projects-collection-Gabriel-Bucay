package com.example.reciperemix.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.RemixText
import com.example.reciperemix.ui.theme.MutedGreen

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PreferencesScreen(
    recipeManager: RecipeManager,
    onThemeChange: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    var favoriteTheme by remember { 
        mutableStateOf(recipeManager.getPreference("favorite_theme", "Cozy Café")) 
    }
    var darkTheme by remember { 
        mutableStateOf(recipeManager.getBooleanPreference("dark_theme", false)) 
    }
    var animationsEnabled by remember { mutableStateOf(true) }
    var selectedDiet by remember { 
        mutableStateOf(recipeManager.getPreference("dietary_preference", "None")) 
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Preferences 🌿", style = MaterialTheme.typography.titleMedium, color = RemixText) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = RemixText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color(0xFFFBF5F0)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            Text("Dietary Preference", style = MaterialTheme.typography.labelLarge, color = RemixText.copy(alpha = 0.6f))
            
            val diets = listOf("None", "Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free")
            FlowRow(
                modifier = Modifier.padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                diets.forEach { diet ->
                    FilterChip(
                        selected = selectedDiet == diet,
                        onClick = { selectedDiet = diet },
                        label = { Text(diet) },
                        shape = RoundedCornerShape(16.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFE89E8A),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Favorite Themes", style = MaterialTheme.typography.labelLarge, color = RemixText.copy(alpha = 0.6f))
            val themes = listOf(
                "Cozy Café" to "☕", "Fantasy" to "🏰", "Cyberpunk" to "🌆", "Gothic" to "🧛"
            )
            
            Row(
                modifier = Modifier.padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                themes.forEach { (name, emoji) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(if (favoriteTheme == name) RemixPrimary.copy(alpha = 0.1f) else Color.White)
                                .border(1.dp, if (favoriteTheme == name) RemixPrimary else Color.LightGray.copy(alpha = 0.3f), CircleShape)
                                .clickable { favoriteTheme = name },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(emoji, fontSize = 28.sp)
                        }
                        Text(name, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Appearance", style = MaterialTheme.typography.labelLarge, color = RemixText.copy(alpha = 0.6f))
            
            PreferenceToggle("Dark Mode", darkTheme, "Toggle Dark Mode") { 
                darkTheme = it
            }
            PreferenceToggle("Animations", animationsEnabled, "Toggle Animations") { 
                animationsEnabled = it
            }

            Spacer(modifier = Modifier.weight(1f))

            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = RemixSecondary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Cook with imagination,\nserve with heart. ✨",
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Serif,
                        color = RemixText
                    )
                }
            }

            Button(
                onClick = {
                    recipeManager.savePreference("favorite_theme", favoriteTheme)
                    recipeManager.saveBooleanPreference("dark_theme", darkTheme)
                    recipeManager.savePreference("dietary_preference", selectedDiet)
                    onThemeChange(darkTheme)
                    onBack()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RemixPrimary)
            ) {
                Text("Save Changes", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PreferenceToggle(label: String, checked: Boolean, contentDescription: String?, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = RemixText)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = MutedGreen),
            modifier = Modifier.semantics { this.contentDescription = contentDescription ?: "" }
        )
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun PreferencesScreenPreview() {
    val context = androidx.compose.ui.platform.LocalContext.current
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            PreferencesScreen(
                recipeManager = RecipeManager(context),
                onThemeChange = {},
                onBack = {}
            )
        }
    }
}
