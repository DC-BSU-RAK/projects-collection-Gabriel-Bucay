package com.example.reciperemix.ui.screens

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.painter.ColorPainter
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.res.Configuration
import androidx.compose.ui.tooling.preview.Preview
import com.example.reciperemix.ui.theme.RecipeRemixTheme
import com.example.reciperemix.ui.theme.RemixPrimary
import com.example.reciperemix.ui.theme.RemixText
import com.example.reciperemix.ui.theme.RemixSecondary
import com.example.reciperemix.ui.theme.MutedGreen

@Composable
fun HomeScreen(
    onStartRemix: () -> Unit,
    onViewSaved: () -> Unit,
    onViewPreferences: () -> Unit,
    onViewAbout: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        AsyncImage(
            model = "https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=1000&auto=format&fit=crop",
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.3f,
            placeholder = ColorPainter(colorScheme.surfaceVariant.copy(alpha = 0.3f)),
            error = ColorPainter(colorScheme.surfaceVariant.copy(alpha = 0.3f))
        )
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = if (isSystemInDarkTheme()) {
                            listOf(colorScheme.background.copy(alpha = 0.8f), colorScheme.background)
                        } else {
                            listOf(Color(0xFFE5D1B8).copy(alpha = 0.6f), colorScheme.background)
                        }
                    )
                )
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(60.dp))
            
            Text(
                text = "RECIPE",
                style = MaterialTheme.typography.displaySmall,
                color = colorScheme.onBackground,
                fontFamily = FontFamily.Serif,
                letterSpacing = 4.sp
            )
            Text(
                text = "Remix",
                style = MaterialTheme.typography.displayMedium,
                color = colorScheme.primary,
                fontFamily = FontFamily.Cursive,
                modifier = Modifier.offset(y = (-12).dp)
            )
            
            Text(
                text = "Turn ingredients into\nimaginative recipes ✨",
                style = MaterialTheme.typography.bodyLarge,
                color = colorScheme.onBackground.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp, bottom = 48.dp)
            )

            Button(
                onClick = onStartRemix,
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = colorScheme.tertiary)
            ) {
                Text("Start Remix", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            HomeOptionItem(
                icon = Icons.Default.FavoriteBorder,
                title = "Saved Recipes",
                subtitle = "Your favorite remixes",
                onClick = onViewSaved,
                contentDescription = "Favorite Recipes Icon"
            )
            HomeOptionItem(
                icon = Icons.Default.Settings,
                title = "Preferences",
                subtitle = "Themes, dietary & more",
                onClick = onViewPreferences,
                contentDescription = "Settings Icon"
            )
            HomeOptionItem(
                icon = Icons.Default.Info,
                title = "About Recipe Remix",
                subtitle = "Our cozy little story",
                onClick = onViewAbout,
                contentDescription = "Information Icon"
            )
        }
    }
}

@Composable
fun HomeOptionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    contentDescription: String?,
    onClick: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = colorScheme.secondaryContainer.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = colorScheme.onSecondaryContainer,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colorScheme.onSecondaryContainer.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Preview(showBackground = true, name = "Light Mode")
@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES, name = "Dark Mode")
@Composable
fun HomeScreenPreview() {
    RecipeRemixTheme(dynamicColor = false) {
        Surface(color = MaterialTheme.colorScheme.background) {
            HomeScreen(
                onStartRemix = {},
                onViewSaved = {},
                onViewPreferences = {},
                onViewAbout = {}
            )
        }
    }
}
