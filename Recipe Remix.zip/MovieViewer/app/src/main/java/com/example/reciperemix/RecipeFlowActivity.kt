package com.example.reciperemix

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.reciperemix.data.RecipeManager
import com.example.reciperemix.ui.screens.AboutScreen
import com.example.reciperemix.ui.screens.IngredientSelectorScreen
import com.example.reciperemix.ui.screens.PreferencesScreen
import com.example.reciperemix.ui.screens.RecipeGenerationScreen
import com.example.reciperemix.ui.screens.SavedRecipesScreen
import com.example.reciperemix.ui.theme.RecipeRemixTheme

class RecipeFlowActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val startDestination = intent.getStringExtra("start_destination") ?: "ingredient_selector"
        
        setContent {
            val context = LocalContext.current
            val recipeManager = remember { RecipeManager(context) }
            var isDarkMode by remember { mutableStateOf(recipeManager.getBooleanPreference("dark_theme", false)) }

            RecipeRemixTheme(darkTheme = isDarkMode) {
                RecipeFlowNavHost(
                    recipeManager = recipeManager,
                    startDestination = startDestination,
                    onThemeChange = { isDarkMode = it },
                    onFinish = { finish() }
                )
            }
        }
    }
}

@Composable
fun RecipeFlowNavHost(
    recipeManager: RecipeManager, 
    startDestination: String,
    onThemeChange: (Boolean) -> Unit,
    onFinish: () -> Unit
) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = startDestination) {
        composable("ingredient_selector") {
            IngredientSelectorScreen(
                recipeManager = recipeManager,
                onGenerateRecipe = { ingredients, theme ->
                    navController.navigate("recipe_generation/$ingredients/$theme")
                },
                onBack = onFinish
            )
        }
        composable("recipe_generation/{ingredients}/{theme}") { backStackEntry ->
            val ingredients = backStackEntry.arguments?.getString("ingredients") ?: ""
            val theme = backStackEntry.arguments?.getString("theme") ?: ""
            RecipeGenerationScreen(
                ingredients = ingredients,
                theme = theme,
                onSaveRecipe = { recipeName -> 
                    recipeManager.saveRecipe(recipeName)
                },
                onViewPlating = { navController.navigate("plating_ideas") },
                onBack = { navController.popBackStack() }
            )
        }
        composable("plating_ideas") {
            com.example.reciperemix.ui.screens.PlatingIdeasScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable("saved_recipes") {
            SavedRecipesScreen(
                recipeManager = recipeManager,
                onNavigateToHome = onFinish,
                onNavigateToPreferences = { navController.navigate("preferences") },
                onBack = onFinish
            )
        }
        composable("preferences") {
            PreferencesScreen(
                recipeManager = recipeManager,
                onThemeChange = onThemeChange,
                onBack = onFinish
            )
        }
        composable("about") {
            AboutScreen(onBack = onFinish)
        }
    }
}
