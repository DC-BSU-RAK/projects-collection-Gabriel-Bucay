package com.example.reciperemix.data

import android.content.Context
import android.content.SharedPreferences

class RecipeManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("recipe_remix_prefs", Context.MODE_PRIVATE)

    fun saveRecipe(recipeName: String) {
        val currentRecipes = getSavedRecipes().toMutableSet()
        currentRecipes.add(recipeName)
        prefs.edit().putStringSet("saved_recipes", currentRecipes).apply()
    }

    fun getSavedRecipes(): List<String> {
        return prefs.getStringSet("saved_recipes", emptySet())?.toList() ?: emptyList()
    }

    fun deleteRecipe(recipeName: String) {
        val currentRecipes = getSavedRecipes().toMutableSet()
        currentRecipes.remove(recipeName)
        prefs.edit().putStringSet("saved_recipes", currentRecipes).apply()
    }

    fun savePreference(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getPreference(key: String, defaultValue: String): String {
        return prefs.getString(key, defaultValue) ?: defaultValue
    }

    fun saveBooleanPreference(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun getBooleanPreference(key: String, defaultValue: Boolean): Boolean {
        return prefs.getBoolean(key, defaultValue)
    }
}
